int puts(const char* str) {
   /* should be implemented for the targetted system */
   return 0;
}
