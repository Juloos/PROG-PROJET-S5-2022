#include <stdio.h>

void afficher() {
	printf("Hello world\n");
}
